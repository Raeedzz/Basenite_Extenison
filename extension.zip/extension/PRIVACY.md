# Privacy — Basanite Capital LinkedIn → Airtable

- **What it reads:** LinkedIn data visible to your signed-in account — connections, profiles, search results, company employees, mutual connections, and conversation *metadata* (timestamps and direction; never message text).
- **Where it goes:** only to the Airtable base and table you configure, using your own personal access token. There is no Basanite or third-party server in between.
- **What's stored locally:** your Airtable token and column mapping, a map of LinkedIn URL → Airtable record id with fingerprints of cells last written, and sync checkpoints — all in `chrome.storage.local` on this browser.
- **When it runs:** when you press a capture button, and on the soft-sync schedule you control in the panel (only after your first manual sync).
- **Removing it:** Airtable tab → Disconnect clears the token and mapping; uninstalling the extension removes all local data.
