import test from "node:test";
import assert from "node:assert/strict";
import { C, COMPANIES, GHOST, cdn, past, setup, sink, state, store } from "./helpers/image-harness.mjs";

const row = (slug) => ({
  name: `Person ${slug}`,
  linkedinUrl: `https://www.linkedin.com/in/${slug}`,
  experience: [{ title: "Analyst", company: "Blank Co", companyUrn: "urn:li:fsd_company:1", startDate: "2021-01" }],
  _earthosEnrichment: { status: "complete" },
});

const blankCo = { id: "recCOMPBLANK00001", fields: { [C.name]: "Blank Co", [C.linkedin]: "https://www.linkedin.com/company/blank-co" } };

test("a cached placeholder logo isn't re-asked every sync", async () => {
  const { asked } = setup({ [COMPANIES]: [blankCo] });
  // Cached details whose logo is LinkedIn's placeholder: the company has no real logo.
  store.set("linkedin_company_details", {
    1: { universalName: "blank-co", name: "Blank Co", logoUrl: GHOST, at: Date.now() },
  });
  state.details = { 1: { universalName: "blank-co", name: "Blank Co", logoUrl: GHOST } };
  await sink.writePeople([row("p1")]);
  await sink.writePeople([row("p2")]);
  await sink.writePeople([row("p3")]);
  // Spec: refetch only when the cached URL has EXPIRED; a placeholder hasn't.
  assert.deepEqual(asked, [], `LinkedIn was asked ${asked.length} times for a company whose cached logo is a placeholder`);
});

test("a failed logo re-ask is retried after the wait, not never", async () => {
  const { base, asked } = setup({ [COMPANIES]: [blankCo] });
  store.set("linkedin_company_details", {
    1: { universalName: "blank-co", name: "Blank Co", logoUrl: cdn("logo-old", { e: past }), at: Date.now() },
  });
  // First re-ask fails transiently (the provider swallows non-session errors and yields null).
  state.details = { 1: null };
  await sink.writePeople([row("p1")]);
  assert.deepEqual(asked, ["1"]);
  // LinkedIn is healthy again; weeks pass.
  state.details = { 1: { universalName: "blank-co", name: "Blank Co", logoUrl: cdn("logo-new") } };
  const realNow = Date.now;
  Date.now = () => realNow() + 30 * 24 * 3600 * 1000;
  try {
    await sink.writePeople([row("p2")]);
  } finally {
    Date.now = realNow;
  }
  const logo = base.state.get(COMPANIES).records.get("recCOMPBLANK00001").fields[C.logo];
  assert.ok(asked.length > 1, "a blank Logo is never looked up again after one failed re-ask (cache now holds logoUrl: \"\")");
  assert.ok(logo, "Logo stays blank forever");
});
